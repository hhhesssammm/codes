"""Assemble release manifests only after exhaustive Phase 2 checks pass."""
from pathlib import Path
import collections,datetime,hashlib,json,platform
import numpy as np
import pandas as pd
import scipy,PIL
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'results'
def read(f):return json.loads((ROOT/f).read_text())
def write(f,o): (ROOT/f).write_text(json.dumps(o,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
samples=read('results/sample_records.json');identity=read('results/identity_summary.json')
capsources=read('caption_verified_sources.json');padding=read('results/repeat_padding_check.json')
crops=read('results/crop_checks.json');corpus=read('results/retrieval_corpus_summary.json')
controls=read('results/alignment_negative_controls.json')
assert identity['records']==identity['unique_nsd_ids']==identity['unique_coco_ids']==982
assert not any(identity[x] for x in ['reappeared_sample_keys','duplicate_members','missing_fields','exact_rgb_duplicate_groups'])
for name in ['cache_pixels_equal_shard','trial_matches_zero_based_design','trial_plus_one_in_official_repetitions',
             'shared1000','subject1_membership','coco_references_whitespace_match','coco_image_metadata_split_matches']:
    assert identity['checks'][name]['pass']==982 and not identity['checks'][name]['fail_rows']
assert identity['max_cache_float_difference']==0
assert padding['all_pass'] and padding['records']==982
assert len(crops['checks'])==20 and all(x['uniquely_closest_expected'] for x in crops['checks'])
for info in identity['caption_files'].values():
    assert info['rows']==982 and info['insertion_order_numeric']
    assert not info['duplicate_json_keys'] and not info['missing_keys'] and not info['extra_keys']
    assert not info.get('invalid_or_empty_caption_keys') and not info.get('invalid_reference_keys')
assert corpus['image_count']==123287 and corpus['all_images_decoded_and_zip_member_CRC_checked']
assert controls['reference_multisets_unique_for_all_targets_in_full_COCO_pool']==982
logs=[]
for a in read('assets.json')+read('image_assets.json'):
    r=read('download_'+a['id']+'.json')
    assert r['status']=='verified_download'
    r['local_path']='data/'+r['filename']
    r['sha256_evidence']='matches pinned Hugging Face LFS SHA-256' if a.get('sha256') else 'computed on downloaded bytes; not a publisher-supplied SHA-256'
    logs.append(r)
cropmap={r['row_index']:r for r in crops['checks']}
padmap={r['row_index']:r for r in padding['checks']}
source_by_label={r['label']:r for r in capsources}
for r in capsources:r['local_path']='captions/'+Path(r['local_path']).name
variants={
    'umbrae':dict(label='UMBRAE original published subject-1 benchmark cache; not brainx-v-1-4',
                  producer_code_revision='8c1795c434a41cdd38ce6628b7e1a774f31d9483'),
    'braincap':dict(label='BrainCap subject-1 comparison cache released in BrainHub',producer_code_revision=None),
    'mindeye2':dict(label='MindEye2 subject-1 comparison cache labelled 40sess',producer_code_revision=None)}
sharedprov=dict(subject='subj01',brainhub_revision='4838666f1a04d0521c2184fa50b5b77e7e7ac5ee',
    shard_dataset_revision='421fb80ea4ca5600c7364ed400f9a5941380c387',
    image_tensor_dataset_revision='77d4f8e1c1d6d417a363ac32c380f12924bd92c8',
    index_rule='raw coco73k.npy equals zero-based NSD nsdId; official MATLAB subjectim/sharedix/masterordering and PNG NSD labels are one-based',
    crop_metadata_order=['top_fraction_removed','bottom_fraction_removed','left_fraction_removed','right_fraction_removed'],
    identity_scope='released benchmark positional association verified against actual archive IDs, image bytes and COCO references',
    checkpoint_weights_or_original_inference_trace_verified=False)
write('results/provenance.json',dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    audit_label_date='2026-10-28',user_confirmed_NSD_agreement_completed=True,
    data_assets=logs,caption_sources=capsources,source_code=read('source_code_inventory.json'),
    shared=sharedprov,decoder_variants=variants,
    environment=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,
        scipy=scipy.__version__,Pillow=PIL.__version__,torch=identity['environment']['torch']),
    model_or_RAG_inference_run=False,
    corpus_exclusion_plan_sha256=sha(ROOT/'exclusion_screen_plan.json'),
    external_evidence=[
        'https://github.com/weihaox/BrainHub/issues/2#issuecomment-2324271310',
        'https://github.com/weihaox/BrainHub/issues/1#issuecomment-2186271204',
        'https://github.com/weihaox/BrainHub/issues/5#issuecomment-2497882317',
        'https://cvnlab.slite.page/p/NKalgWd__F/Experiments']))

asset_by_name={r['filename']:r for r in logs}
sample_output=[]
for s in samples:
    r=dict(s)
    r['subject']='subj01'
    r['shard_sha256']=asset_by_name[r['shard']]['actual_sha256']
    r['shard_dataset_revision']=sharedprov['shard_dataset_revision']
    r['repeat_padding_check']=padmap[r['row_index']]
    r['official_crop_comparison']=cropmap.get(r['row_index'])
    r['official_crop_comparison_status']='checked' if r['row_index'] in cropmap else 'not selected for official PNG spot check'
    r['validation_status']='PASS: full identity mapping; official crop spot-check scope recorded separately'
    sample_output.append(r)
with (OUT/'sample_manifest.jsonl').open('w') as f:
    for r in sample_output:f.write(json.dumps(r,separators=(',',':'))+'\n')

caption_output=[]
for label in ['umbrae','braincap','mindeye2']:
    src=source_by_label[label];captions=json.loads((ROOT/src['local_path']).read_text())
    assert sha(ROOT/src['local_path'])==src['sha256']
    for s in sample_output:
        key=s['caption_key'];text=captions[key]
        row=dict(manifest_row_id=f'{label}:subj01:{key}',decoder=label,decoder_variant=variants[label],
            model_checkpoint_sha256=None,model_checkpoint_provenance_status='not independently verified; released output file is the frozen analysis input',
            subject='subj01',caption_key=key,caption_row_index=s['row_index'],
            caption_utf8_sha256=hashlib.sha256(text.encode()).hexdigest(),caption_file=src['local_path'],
            caption_file_sha256=src['sha256'],caption_git_blob_sha1=src['sha'],caption_source_url=src['url'],
            caption_repository_revision=sharedprov['brainhub_revision'],
            sample_key=s['sample_key'],shard=s['shard'],shard_record_index=s['shard_record_index'],
            shard_sha256=s['shard_sha256'],shard_dataset_revision=sharedprov['shard_dataset_revision'],
            raw_coco73k=s['coco73k.npy'],raw_trial=s['trial.npy'],raw_num_uniques=s['num_uniques.npy'],
            raw_id_array_shape=s['members']['coco73k.npy']['shape'],raw_id_array_dtype=s['members']['coco73k.npy']['dtype'],
            nsd_id_zero_based=s['nsd_id_zero_based'],nsd_id_one_based=s['nsd_id_one_based'],
            coco_image_id=s['coco_image_id'],coco_split=s['coco_split'],coco_annotation_ids=s['coco_annotation_ids'],
            crop_box=s['crop_box'],crop_box_convention=sharedprov['crop_metadata_order'],
            shared_position_one_based=s['shared_position_one_based'],official_crop_url=s['official_png_url'],
            official_crop_file_sha256=(cropmap[s['row_index']]['file_sha256'] if s['row_index'] in cropmap else None),
            official_crop_comparison_status=s['official_crop_comparison_status'],
            archive_jpeg_sha256=s['members']['jpg']['sha256'],archive_rgb_sha256=s['members']['jpg']['rgb_sha256'],
            cache_pixels_equal_shard=s['cache_pixels_equal_shard'],trial_design_check=s['trial_matches_zero_based_design'],
            coco_reference_exact_check=s['coco_references_exact_match'],coco_reference_whitespace_normalized_check=s['coco_references_whitespace_match'],
            reference_normalization='Python whitespace collapse: " ".join(text.split()); no semantic normalization',
            observed_repetitions=s['available_repetitions_first37'],repeat_padding=padmap[s['row_index']]['rule'],
            response_unit='one released caption per stimulus and decoder; not an independent single trial',
            validation_status='PASS_RELEASED_BENCHMARK_ALIGNMENT',
            shared_provenance_file='results/provenance.json',sample_manifest_file='results/sample_manifest.jsonl')
        caption_output.append(row)
with (OUT/'alignment_manifest.jsonl').open('w') as f:
    for r in caption_output:f.write(json.dumps(r,separators=(',',':'))+'\n')

# Conservative target grouping for later stimulus-disjoint pilot/confirmation splits.
# This defines groups, not the Phase 3 study allocation.
target_ids={r['coco_image_id'] for r in samples};parent={i:i for i in target_ids}
def root(i):
    while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
    return i
edges=set()
for line in (OUT/'retrieval_exclusions.jsonl').read_text().splitlines():
    r=json.loads(line);i=r['coco_image_id']
    if i not in target_ids:continue
    other=set(t for v in r['exact_identity_matches'].values() for t in v)
    other.update(m['target_coco_id'] for m in r['near_duplicate_matches'])
    for j in other:
        if j in target_ids and i!=j:
            edges.add(tuple(sorted([i,j])));parent[root(i)]=root(j)
groups=collections.defaultdict(list)
for i in target_ids:groups[root(i)].append(i)
components=sorted([sorted(v) for v in groups.values()],key=lambda x:x[0])
write('results/target_similarity_groups.json',dict(rule='Connected components of target-to-target exact alias or prespecified pHash screen edges. Potential matches are not confirmed duplicates.',
    components=components,non_singleton_components=[c for c in components if len(c)>1],edges=[list(e) for e in sorted(edges)],
    pilot_confirmatory_split_created=False))

# Round-trip checks on the actual written manifests, not only in-memory counts.
actual=[json.loads(s) for s in (OUT/'alignment_manifest.jsonl').read_text().splitlines()]
actual_samples=[json.loads(s) for s in (OUT/'sample_manifest.jsonl').read_text().splitlines()]
assert len(actual)==2946 and len({r['manifest_row_id'] for r in actual})==2946
assert len(actual_samples)==982 and len({r['sample_key'] for r in actual_samples})==982
assert set(r['caption_key'] for r in actual)==set(map(str,range(982)))
for r in actual:
    s=actual_samples[r['caption_row_index']]
    assert all(r[k]==s[k] for k in ['sample_key','nsd_id_zero_based','coco_image_id','shard','shard_record_index'])
assert len({r['coco_image_id'] for r in actual})==982
write('results/manifest_integrity_check.json',dict(caption_rows=2946,unique_caption_row_ids=2946,
    rows_per_decoder=dict(collections.Counter(r['decoder'] for r in actual)),sample_rows=982,
    all_caption_to_sample_joins_pass=True,all_required_identity_gates_pass=True,
    manifest_sha256=sha(OUT/'alignment_manifest.jsonl'),sample_manifest_sha256=sha(OUT/'sample_manifest.jsonl'),
    target_similarity_non_singleton_groups=sum(len(c)>1 for c in components),
    target_similarity_grouped_stimuli=sum(len(c) for c in components if len(c)>1),
    phase2_recommendation='GO for review of the verified cached-benchmark route; Phase 3 not started'))
print((OUT/'manifest_integrity_check.json').read_text())
