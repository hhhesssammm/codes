"""Download the pinned Phase 2 assets and verify their sizes and hashes."""
import concurrent.futures, hashlib, json, pathlib, sys, threading, time, urllib.request
from datetime import datetime, timezone
from urllib.parse import urlparse

ROOT = pathlib.Path(__file__).resolve().parent
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)
LOCK = threading.Lock()

def emit(obj):
    with LOCK:
        print(json.dumps(obj), flush=True)

def download(asset):
    dest = DATA / asset["filename"]
    record = dict(asset, started_utc=datetime.now(timezone.utc).isoformat())
    if dest.exists():
        h = hashlib.sha256()
        with dest.open("rb") as f:
            for block in iter(lambda: f.read(8*1024*1024), b""): h.update(block)
        if dest.stat().st_size == asset.get("bytes", dest.stat().st_size) and (not asset.get("sha256") or h.hexdigest() == asset["sha256"]):
            return dict(record, local_path=str(dest), actual_bytes=dest.stat().st_size,
                        actual_sha256=h.hexdigest(), status="verified_existing")
        raise ValueError("Existing file differs from expected: "+str(dest))
    part = dest.with_suffix(dest.suffix + ".part")
    for attempt in range(1,4):
        try:
            h = hashlib.sha256(); count = 0; last = time.monotonic()
            with urllib.request.urlopen(asset["url"], timeout=90) as r, part.open("wb") as f:
                record.update(http_status=r.status, resolved_host=urlparse(r.url).hostname,
                              etag=r.headers.get("ETag"), last_modified=r.headers.get("Last-Modified"))
                while True:
                    block=r.read(8*1024*1024)
                    if not block: break
                    f.write(block);h.update(block);count+=len(block)
                    if time.monotonic()-last>20:
                        emit({"asset":asset["id"],"downloaded_MB":round(count/1e6,1)})
                        last=time.monotonic()
            actual=h.hexdigest()
            if "bytes" in asset and count!=asset["bytes"]: raise ValueError("size mismatch")
            if "sha256" in asset and actual!=asset["sha256"]: raise ValueError("SHA-256 mismatch")
            part.replace(dest)
            record.update(local_path=str(dest),actual_bytes=count,actual_sha256=actual,
                          status="verified_download",completed_utc=datetime.now(timezone.utc).isoformat())
            (ROOT/("download_"+asset["id"]+".json")).write_text(json.dumps(record,indent=2)+"\n")
            emit({"asset":asset["id"],"status":record["status"],"bytes":count,"sha256":actual})
            return record
        except Exception as e:
            emit({"asset":asset["id"],"attempt":attempt,"error":str(e)})
            if attempt==3:
                record.update(status="failed",error=str(e))
                (ROOT/("download_"+asset["id"]+".json")).write_text(json.dumps(record,indent=2)+"\n")
                return record
            time.sleep(attempt)

if __name__=="__main__":
    config=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/"assets.json"
    assets=json.loads(config.read_text())
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:
        results=list(ex.map(download,assets))
    (ROOT/"download_results.json").write_text(json.dumps(results,indent=2)+"\n")
    if any(r["status"]=="failed" for r in results):sys.exit(1)

