"""Exhaustive prespecified COCO image fingerprint screen. No retrieval/model run.

Read JPEGs within ZIP archives, avoiding extraction of the 20 GB image corpus.
All threshold matches are potential near-duplicates, not adjudicated duplicates.
"""
from pathlib import Path
import collections,concurrent.futures,hashlib,io,json,re,sys,time,zipfile
import numpy as np
import pandas as pd
from PIL import Image
from scipy.fft import dctn
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'results'
records=json.loads((OUT/'sample_records.json').read_text())
assert len(records)==982 and len({r['nsd_id_zero_based'] for r in records})==982
assert all(r['trial_matches_zero_based_design'] and r['coco_references_whitespace_match'] for r in records)
plan=json.loads((ROOT/'exclusion_screen_plan.json').read_text())
assert plan['near_duplicate_rule']['hamming_distance_max']==8
metadata={int(k):v for k,v in json.loads((OUT/'coco_images_metadata.json').read_text()).items()}
target_ids={r['coco_image_id'] for r in records}

def phash(im):
    a=np.asarray(im.convert('L').resize((32,32),Image.Resampling.LANCZOS),dtype=np.float64)
    d=dctn(a,type=2,norm='ortho')[:8,:8];bits=(d>np.median(d)).ravel()
    return sum(int(b)<<i for i,b in enumerate(bits))

def fingerprint(job):
    split,z,name=job; image_id=int(Path(name).stem);b=z.read(name)
    with Image.open(io.BytesIO(b)) as im:
        im=im.convert('RGB');w,h=im.size
        assert (w,h)==(metadata[image_id]['width'],metadata[image_id]['height'])
        rgb_sha=hashlib.sha256(im.tobytes()).hexdigest()
        side=min(w,h);left=(w-side)//2;top=(h-side)//2
        square=im.crop((left,top,left+side,top+side))
        hashes=[phash(im),phash(im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)),
                phash(square),phash(square.transpose(Image.Transpose.FLIP_LEFT_RIGHT))]
    assert metadata[image_id]['split']==split
    return (image_id,w,h,hashlib.sha256(b).hexdigest(),rgb_sha,*hashes)

indexfile=OUT/'coco_image_fingerprints.npz'
if not indexfile.exists() or '--force-image-scan' in sys.argv:
    allrows=[];start=time.monotonic()
    for split in ['train2017','val2017']:
        with zipfile.ZipFile(ROOT/'data'/f'{split}.zip') as z:
            names=[n for n in z.namelist() if n.lower().endswith('.jpg')]
            ids=[int(Path(n).stem) for n in names]
            assert len(ids)==len(set(ids))
            assert set(ids)=={i for i,v in metadata.items() if v['split']==split}
            with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
                for i,row in enumerate(ex.map(fingerprint,((split,z,n) for n in names))):
                    allrows.append(row)
                    if (i+1)%5000==0:print(json.dumps(dict(split=split,processed=i+1,elapsed_s=round(time.monotonic()-start))),flush=True)
    allrows.sort(key=lambda x:x[0])
    np.savez_compressed(indexfile,ids=np.array([r[0] for r in allrows],dtype=np.int64),
        sizes=np.array([r[1:3] for r in allrows],dtype=np.int32),
        jpeg_sha256=np.array([r[3] for r in allrows],dtype='S64'),
        rgb_sha256=np.array([r[4] for r in allrows],dtype='S64'),
        phashes=np.array([r[5:] for r in allrows],dtype=np.uint64))
with np.load(indexfile,allow_pickle=False) as f:index={k:f[k] for k in f.files}
assert len(index['ids'])==123287 and set(map(int,index['ids']))==set(metadata)
position={int(i):j for j,i in enumerate(index['ids'])}
targethashes=[];targetrefs=[]
for r in records:
    targethashes.append(index['phashes'][position[r['coco_image_id']],0]);targetrefs.append((r['coco_image_id'],r['row_index'],'full'))
    with Image.open(ROOT/'shard_images'/f"{r['row_index']:04d}.jpg") as im:targethashes.append(phash(im))
    targetrefs.append((r['coco_image_id'],r['row_index'],'nsd_crop'))
bank=np.array(targethashes,dtype=np.uint64)
views=['full','horizontal_flip','center_square','center_square_horizontal_flip']
near={};nearest_distances=np.full(len(index['ids']),64,dtype=np.uint8)
for start in range(0,len(index['ids']),256):
    chunk=index['phashes'][start:start+256]
    dist=np.bitwise_count(chunk[:,:,None]^bank[None,None,:])
    nearest_distances[start:start+len(chunk)]=dist.min(axis=(1,2))
    a,b,c=np.where(dist<=8)
    for i,v,t in zip(a.tolist(),b.tolist(),c.tolist()):
        iid=int(index['ids'][start+i]);tid,trow,tview=targetrefs[t]
        near.setdefault(iid,[]).append(dict(target_coco_id=tid,target_caption_key=str(trow),
            target_view=tview,candidate_view=views[v],hamming_distance=int(dist[i,v,t])))
    if start%12800==0:print(json.dumps(dict(comparison_images=min(start+256,len(index['ids'])))),flush=True)

def flickr_id(m):
    name=str(m.get('flickr_url') or '').rsplit('/',1)[-1]
    hit=re.match(r'(\d+)_',name)
    return hit.group(1) if hit else None
alias=collections.defaultdict(list);jpegs=collections.defaultdict(list);rgbs=collections.defaultdict(list)
for tid in sorted(target_ids):
    i=position[tid];fid=flickr_id(metadata[tid])
    if fid:alias[fid].append(tid)
    jpegs[index['jpeg_sha256'][i].decode()].append(tid)
    rgbs[(index['rgb_sha256'][i].decode(),*map(int,index['sizes'][i]))].append(tid)
meta=pd.read_csv(ROOT/'data/nsd_stim_info_merged.csv')
shared_ids=set(map(int,meta.loc[meta.shared1000,'cocoId']))
assert len(shared_ids)==1000 and shared_ids.issubset(metadata) and target_ids.issubset(shared_ids)
exclusions=[];reasons=collections.Counter()
for i,id_ in enumerate(index['ids']):
    iid=int(id_);why=[];exact={}
    if iid in shared_ids:why.append('NSD_shared1000_held_out')
    fid=flickr_id(metadata[iid]);same_flickr=[t for t in alias.get(fid,[]) if t!=iid] if fid else []
    same_jpeg=[t for t in jpegs.get(index['jpeg_sha256'][i].decode(),[]) if t!=iid]
    same_rgb=[t for t in rgbs.get((index['rgb_sha256'][i].decode(),*map(int,index['sizes'][i])),[]) if t!=iid]
    for label,values in [('same_Flickr_photo_id',same_flickr),('same_JPEG_SHA256',same_jpeg),('same_RGB_SHA256_and_size',same_rgb)]:
        if values:why.append(label);exact[label]=values
    matches=[m for m in near.get(iid,[]) if m['target_coco_id']!=iid]
    if matches:why.append('potential_near_duplicate_pHash_le_8')
    if why:
        reasons.update(why)
        exclusions.append(dict(coco_image_id=iid,split=metadata[iid]['split'],reasons=why,
            exact_identity_matches=exact,near_duplicate_matches=matches))
excluded_ids={r['coco_image_id'] for r in exclusions}
with (OUT/'retrieval_exclusions.jsonl').open('w') as f:
    for r in exclusions:f.write(json.dumps(r,separators=(',',':'))+'\n')
kept=sorted(set(metadata)-excluded_ids)
(OUT/'eligible_coco_image_ids.txt').write_text(''.join(f'{i}\n' for i in kept))
caption_ids=[];caption_counts={};allcapids=[];orphans=[]
with zipfile.ZipFile(ROOT/'data/annotations_trainval2017.zip') as z:
    for split in ['train2017','val2017']:
        annotations=json.loads(z.read(f'annotations/captions_{split}.json'))['annotations']
        chosen=[a['id'] for a in annotations if a['image_id'] not in excluded_ids]
        allcapids.extend(a['id'] for a in annotations)
        orphans.extend(a['id'] for a in annotations if a['image_id'] not in metadata)
        caption_ids.extend(chosen);caption_counts[split]=dict(total=len(annotations),eligible=len(chosen))
assert len(allcapids)==len(set(allcapids)) and not orphans
(OUT/'eligible_coco_caption_ids.txt').write_text(''.join(f'{i}\n' for i in sorted(caption_ids)))
summary=dict(identity_gate_passed_before_screen=True,image_count=len(metadata),
    all_image_ids_unique=True,all_image_dimensions_match_annotations=True,
    all_images_decoded_and_zip_member_CRC_checked=True,
    all_caption_ids_unique=True,orphan_caption_ids=orphans,
    held_out_shared1000_images=len(shared_ids),evaluated_target_images=len(target_ids),
    excluded_images=len(exclusions),eligible_images=len(kept),
    exclusion_reason_counts=dict(reasons),
    additional_excluded_images_beyond_shared1000=len(excluded_ids-shared_ids),
    caption_counts=caption_counts,eligible_captions=len(caption_ids),
    target_full_hash_self_matches=sum(int(np.min(np.bitwise_count(index['phashes'][position[tid]]^bank[2*j])))==0 for j,tid in enumerate(r['coco_image_id'] for r in records)),
    plan=plan,near_duplicates_adjudicated_as_confirmed=False,
    image_fingerprint_file_sha256=hashlib.sha256(indexfile.read_bytes()).hexdigest(),
    nearest_hamming_distance_distribution=dict(collections.Counter(map(int,nearest_distances))))
(OUT/'retrieval_corpus_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['plan','nearest_hamming_distance_distribution']},indent=2))
