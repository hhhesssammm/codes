"""Verify the preselected official NSD display crops; no caption scoring."""
from pathlib import Path
import concurrent.futures, hashlib, io, json, urllib.request
import numpy as np
from PIL import Image, ImageDraw
from scipy.fft import dctn

ROOT=Path(__file__).resolve().parent; OUT=ROOT/"results"; OFF=ROOT/"official_crops";OFF.mkdir(exist_ok=True)
records=json.loads((OUT/"sample_records.json").read_text())
selection=json.loads((OUT/"crop_check_selection.json").read_text())
def phash(im):
    a=np.asarray(im.convert("L").resize((32,32),Image.Resampling.LANCZOS),dtype=np.float64)
    d=dctn(a,type=2,norm="ortho")[:8,:8];bits=(d>np.median(d)).ravel()
    return sum(int(b)<<i for i,b in enumerate(bits))
cache_ph=[]
for j in range(len(records)):
    with Image.open(ROOT/"shard_images"/f"{j:04d}.jpg") as im:cache_ph.append(phash(im))
def fetch(r):
    dest=OFF/r["official_png_name"]
    if dest.exists():b=dest.read_bytes()
    else:
        with urllib.request.urlopen(r["official_png_url"],timeout=40) as resp:b=resp.read()
        dest.write_bytes(b)
    with Image.open(io.BytesIO(b)) as im:
        im=im.convert("RGB");size=im.size;official_rgb=np.array(im);h=phash(im)
        a=np.array(im.resize((256,256),Image.Resampling.BICUBIC),dtype=np.float64)
    with Image.open(ROOT/"shard_images"/f"{r['row_index']:04d}.jpg") as im:bimg=np.array(im.convert("RGB"),dtype=np.float64)
    mse=float(np.mean((a-bimg)**2));corr=float(np.corrcoef(a.ravel(),bimg.ravel())[0,1])
    dist=np.array([(h^v).bit_count() for v in cache_ph])
    expected=int(dist[r["row_index"]]);mins=np.flatnonzero(dist==dist.min()).tolist()
    out=dict(row_index=r["row_index"],nsd_id_zero_based=r["nsd_id_zero_based"],coco_image_id=r["coco_image_id"],
      url=r["official_png_url"],file_sha256=hashlib.sha256(b).hexdigest(),
      official_rgb_sha256=hashlib.sha256(official_rgb.tobytes()).hexdigest(),
      official_size=list(size),compared_size=[256,256],transform="Pillow BICUBIC resize; RGB",
      rgb_correlation=corr,rmse=float(np.sqrt(mse)),psnr_db=float(20*np.log10(255/np.sqrt(mse))) if mse else None,
      phash_hex=f"{h:016x}",phash_distance_to_expected=expected,closest_cache_rows=mins,
      uniquely_closest_expected=mins==[r["row_index"]])
    return out
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:checks=list(ex.map(fetch,selection["samples"]))
(OUT/"crop_checks.json").write_text(json.dumps(dict(selection=selection["method"],checks=checks),indent=2)+"\n")
# These are internal QA contact sheets, not distributable data releases.
for page in range(2):
    chosen=selection["samples"][page*10:(page+1)*10]
    sheet=Image.new("RGB",(840,1120),"white");draw=ImageDraw.Draw(sheet)
    for idx,r in enumerate(chosen):
        col=idx%2;row=idx//2;x=col*420;y=row*220
        draw.text((x+6,y+3),f"row {r['row_index']} / NSD {r['nsd_id_zero_based']} / COCO {r['coco_image_id']}",fill="black")
        draw.text((x+6,y+20),"Official 425 crop        Archive 256 JPEG",fill="black")
        for k,p in enumerate([OFF/r["official_png_name"],ROOT/"shard_images"/f"{r['row_index']:04d}.jpg"]):
            with Image.open(p) as im:sheet.paste(im.convert("RGB").resize((180,180),Image.Resampling.BICUBIC),(x+6+k*204,y+38))
    sheet.save(OUT/f"crop_contact_sheet_{page+1}.png")
print(json.dumps(dict(n=len(checks),rows=[c["row_index"] for c in checks],
    official_sizes=sorted(set(tuple(c["official_size"]) for c in checks)),
    min_rgb_correlation=min(c["rgb_correlation"] for c in checks),
    max_rmse=max(c["rmse"] for c in checks),
    max_phash_distance=max(c["phash_distance_to_expected"] for c in checks),
    uniquely_closest_expected=sum(c["uniquely_closest_expected"] for c in checks)),indent=2))

