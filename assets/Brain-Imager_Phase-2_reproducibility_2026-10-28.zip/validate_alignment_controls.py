"""Independent joins and deliberately wrong ID/order controls; no model run."""
from pathlib import Path
import collections,hashlib,json,zipfile
import numpy as np
import pandas as pd
from scipy.io import loadmat
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'results'
records=json.loads((OUT/'sample_records.json').read_text())
refs=json.loads((ROOT/'captions/references_fmri_cococap.json').read_text())
meta=pd.read_csv(ROOT/'data/nsd_stim_info_merged.csv').set_index('nsdId')
d=loadmat(ROOT/'data/nsd_expdesign.mat')
seq=d['subjectim'][0,d['masterordering'].ravel().astype(int)-1].astype(int)-1
allrefs=collections.defaultdict(list)
with zipfile.ZipFile(ROOT/'data/annotations_trainval2017.zip') as z:
    for split in ['train2017','val2017']:
        for a in json.loads(z.read(f'annotations/captions_{split}.json'))['annotations']:
            allrefs[a['image_id']].append(a['caption'])
def normalized_multiset(strings):return tuple(sorted(' '.join(s.split()) for s in strings))
reverse=collections.defaultdict(list)
for coco,strings in allrefs.items():reverse[normalized_multiset(strings)].append(coco)
unique_reference_matches=sum(reverse[normalized_multiset(refs[r['caption_key']])]==[r['coco_image_id']] for r in records)
assert unique_reference_matches==982
rotated=records[1:]+records[:1]
wrong_trials=sum(bool(seq[r['trial.npy']]==wrong['nsd_id_zero_based']) for r,wrong in zip(records,rotated))
wrong_refs=sum(normalized_multiset(refs[r['caption_key']])==normalized_multiset(allrefs[wrong['coco_image_id']]) for r,wrong in zip(records,rotated))
wrong_pixels=sum(r['cache_uint8_rgb_sha256']==wrong['members']['jpg']['rgb_sha256'] for r,wrong in zip(records,rotated))
offbyone_trials=sum(bool(seq[r['trial.npy']]==r['nsd_id_zero_based']+1) for r in records)
offbyone_refs=sum(normalized_multiset(refs[r['caption_key']])==normalized_multiset(allrefs[int(meta.loc[r['nsd_id_zero_based']+1,'cocoId'])]) for r in records)
raw_differing_captions=sum(sum((collections.Counter(refs[r['caption_key']])-collections.Counter(allrefs[r['coco_image_id']])).values()) for r in records)
out=dict(reference_multisets_unique_for_all_targets_in_full_COCO_pool=unique_reference_matches,
    shifted_row_order_control=dict(trial_matches=wrong_trials,reference_matches=wrong_refs,pixel_matches=wrong_pixels),
    nsd_plus_one_control=dict(trial_matches=offbyone_trials,reference_matches=offbyone_refs),
    raw_reference_caption_instances_differing_only_by_whitespace=raw_differing_captions,
    mapping_was_derived_from_ID_metadata_not_reference_text=True)
assert not any([wrong_trials,wrong_refs,wrong_pixels,offbyone_trials,offbyone_refs])
(OUT/'alignment_negative_controls.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
