# Brain-Imager: Phase 2 data-level validation

**Decision for review: the required checks pass for the frozen, published subject-1 caption caches. Recommend GO for that cached-benchmark route. Phase 3 has not started.**

Audit label: 28 October 2026. Machine acquisition timestamps are recorded in UTC
on 27 October 2026; the sampling salt and filenames retain the fixed audit label.
This report continues the 27 October source/alignment audit. The user confirmed
completion of the NSD data-access agreement before this data processing.

The caption-to-stimulus mapping was recovered without rerunning a brain decoder.
No LLM, embedding model, RAG retrieval/generation experiment or caption factuality
annotation was run. The COCO image screen below is a data-exclusion audit.
Sider Scholar was not used.

**What has been validated**

The two actual subject-1 archives contain **500 + 482 = 982 records**. Their
archive order, preserved without sorting sample keys, supplies the positional
caption-key sequence. All three candidate caption files contain exactly 982
valid keys, giving **2,946 candidate-caption rows over 982 unique stimuli**.

This conclusion rests on exhaustive checks of the actual ID arrays, cached
image contents, official trial design and reference annotations. Source-code
inspection, matching counts and a visual spot check are supplementary evidence.

| Check on actual files | Result |
|---|---|
| Archive sizes and pinned HF LFS SHA-256 checks | Both test archives and `all_images.pt` match their pinned sizes and hashes |
| Archive record counts | 500 in shard 0; 482 in shard 1 |
| Unique sample keys / NSD IDs / COCO IDs | 982 / 982 / 982 |
| Reappearing sample keys, duplicate members, missing required fields | 0 / 0 / 0 |
| Raw ID representation | Every `coco73k.npy`, `trial.npy` and `num_uniques.npy` is an integer array of shape `[1]`, dtype `int64` |
| Caption keys, all three decoders | Exactly string keys `0`–`981`, in numeric insertion order; no duplicate JSON keys, gaps, extra keys or empty/non-string captions |
| Cached image tensor | Actual shape `[982, 3, 256, 256]`, float32 |
| Cached image versus corresponding archive JPEG | 982/982 exact RGB-pixel matches; also exact float equality to RGB/255; maximum float difference 0 |
| Exact duplicate archive RGB images | None among 982 |
| Raw trial and stimulus versus official MATLAB design | 982/982 agree with the zero-based trial interpretation |
| Alternative one-based interpretation of the raw trial field | 0/982 matches |
| Trial + 1 among official subject-1 repetitions | 982/982 |
| Subject-1 membership and shared-1000 membership | 982/982 each |
| COCO image ID, annotation membership and split joins | 982/982; every target is in COCO train2017 |
| Reference-caption multiset, exact strings | 588/982 rows |
| Reference-caption multiset, whitespace normalization only | 982/982 rows; all 982 sets uniquely match the expected image in the full COCO caption pool |
| Deliberately rotated row order | 0/982 pass the trial, reference or image checks |
| Deliberately adding 1 to the NSD ID | 0/982 pass the trial or reference checks |
| Final written manifests | 2,946 unique caption-row keys; 982 unique sample rows; every cross-manifest join passes |

There are 4,913 human references: 979 images have five and three images have six.
The 394 rows failing raw string equality differ only in whitespace: 477 reference
caption instances differ. The only normalization was Python
`" ".join(text.split())`. No paraphrase matching, punctuation normalization or
semantic similarity was used to invent or repair the ID mapping.

The exact source captions were fetched again at the pinned commit and verified
against Git blob SHA-1 and SHA-256. Earlier local working copies had one extra
trailing newline. Their parsed JSON was identical; the source-byte discrepancy
has been resolved by using the freshly verified copies.

| Candidate cache | Actual rows | Distinct caption texts | Repeated-text groups |
|---|---:|---:|---:|
| Original UMBRAE subject 1 | 982 | 813 | 85 |
| BrainCap subject-1 comparison file | 982 | 883 | 63 |
| MindEye2 subject-1 file labelled `40sess` | 982 | 470 | 152 |

Repeated text is not evidence of repeated stimulus identity. These text repeats
were retained. The `40sess` filename is a decoder-cache label, not proof that
each evaluation stimulus has three observed trials.

**Recovered sequence and index conversions**

The [maintainer's ordering explanation](https://github.com/weihaox/BrainHub/issues/2#issuecomment-2324271310)
and [pinned UMBRAE exporter](https://github.com/weihaox/UMBRAE/blob/8c1795c434a41cdd38ce6628b7e1a774f31d9483/umbrae/inference.py)
establish the positional-key contract. The actual data validate it as follows:

1. Read shard 0 then shard 1, preserving member/record order. Caption key `j`
   joins to the j-th record, not to a numerically interpreted sample-key suffix.
2. Retain the raw `coco73k.npy` value. Despite its name, it is a **zero-based NSD
   stimulus index**, not a COCO image ID.
3. Join that value to the official CSV `nsdId`. The downloaded CSV has 73,000
   unique IDs, exactly 0–72,999, equal to its first index column.
4. Convert the official MATLAB indices from one-based to zero-based:
   `sequence0 = subjectim[0, masterordering - 1] - 1`.
   For every record, `sequence0[raw_trial] == raw_coco73k`.
5. Obtain `cocoId`, `cocoSplit` and `cropBox` from the joined metadata row.
   Official PNG NSD labels and positions within `sharedix` are one-based.

These conventions are documented in the [official NSD experiment manual](https://cvnlab.slite.page/p/NKalgWd__F/Experiments).
`cropBox` records fractions removed in top, bottom, left, right order. The actual
CSV and MATLAB files, their hashes and every conversion result are preserved
in the provenance and manifests.

| Caption key | Raw sample key | Zero-based NSD ID | COCO image ID | Raw zero-based trial |
|---|---|---:|---:|---:|
| 0 | sample000000349 | 2950 | 262145 | 2615 |
| 1 | sample000000355 | 2990 | 262239 | 18457 |
| 2 | sample000000365 | 3049 | 262414 | 6298 |
| 981 | sample000009831 | 72948 | 517878 | See full manifest |

The full ID sequence is in `sample_manifest.jsonl`; the table is illustrative.
Raw NSD IDs are strictly increasing in the recovered order, but sorting was
not used to construct that order.

The candidate set is **exactly the shared-1000 images encountered by subject 1
in the first 27,750 trials (37 sessions)**. The other 18 shared images are
explicitly listed in `identity_summary.json`. Thus 982 is an observed result
with an independently checked design explanation, not an assumed benchmark size.

**Response aggregation and padding**

All stored ROI response arrays have shape `[3, 15724]` and dtype float16.
Official repetition metadata and stored `num_uniques` agree for every stimulus:
839 have three observed responses, 110 have two, and 33 have one, totalling
2,770 observed trials.

For all 110 two-response records, the third row is exactly the float32 mean
of the first two, cast back to float16. For all 33 one-response records, all
three stored rows are identical. Three-response records have three distinct
rows. This resolves the initial diagnostic that only 872 records had as many
distinct stored rows as `num_uniques`; a mean-padding row is itself distinct.
The diagnostic remains in the evidence rather than being hidden.

The UMBRAE exporter averages the repeat dimension. These released captions are
therefore stimulus-level outputs, not 2,946 independent neural trials. The
audit did not compare voxel values with original NSD beta volumes or reproduce
each decoder's original inference trace.

**Official displayed-crop check**

Twenty rows were selected by the lowest SHA-256 ranks of the fixed UTF-8 string
`Brain-Imager|Phase2|2026-10-28|<caption_key>`, before inspecting their images.
This deterministic pseudorandom selection avoids dependence on a random-number
generator version. Selected rows, in selection order:

`943, 898, 402, 706, 529, 521, 737, 748, 555, 42, 746, 721, 766, 349, 657, 71, 433, 438, 317, 601`.

All 20 official `sharedAAAA_nsdBBBBB.png` files downloaded successfully from
the official NSD bucket and were 425×425 RGB. They were compared with the
corresponding 256×256 archive JPEG after a fixed Pillow bicubic resize:

- Minimum RGB correlation: **0.989415**.
- Maximum RGB RMSE: **8.8380** on the 0–255 scale.
- pHash distance to the expected archive image: **0 for all 20**.
- Expected image uniquely closest among all 982 archived images: **20/20**.
- Assistant visual inspection of both contact sheets: all 20 image/crop pairs
  consistent. This was not independent human annotation or factuality scoring.

The 425-pixel PNGs and 256-pixel JPEGs are not claimed to be pixel-identical.
PNG URLs, individual file hashes, transforms and comparison results are recorded.
The other 962 official PNGs were not downloaded for this spot check; their crop
URLs and metadata are recorded, and their archive/cached-image correspondence
was exhaustively checked. The 20-image check alone does not establish the full join.

**Retrieval-corpus exclusions, defined after the identity gate passed**

The prospective pool is COCO 2017 train plus validation captions. This is an
identity list and exclusion definition, not a retrieval index or experiment.
All 123,287 corresponding JPEGs were read from the official image ZIPs, decoded,
checked against annotated image dimensions, and subjected to ZIP-member CRC
checks. Image IDs and all 616,767 caption IDs are unique; no caption has a missing
parent image.

The plan was written before the image-fingerprint scan. It excludes every image
in the shared NSD 1,000, including all 982 targets, and all captions attached to
an excluded image. Exact duplicate checks use Flickr photo IDs, JPEG SHA-256,
and decoded RGB SHA-256 with dimensions. No additional exact alias was found
against the evaluation targets under these rules.

Potential near-duplicates use a specified 64-bit DCT pHash with Hamming distance
at most 8. Candidate views are full image, horizontal flip, centre-square crop
and its horizontal flip. Target views are the original COCO image and validated
NSD archive crop. Every threshold candidate is conservatively excluded without
claiming it is a confirmed duplicate.

| Exclusion/pool result | Actual count |
|---|---:|
| Starting images / captions | 123,287 / 616,767 |
| Shared NSD images excluded | 1,000 |
| Images triggering a non-self pHash match | 85 |
| Additional exclusions beyond shared-1000 | 83 |
| Total excluded images / captions | 1,083 / 5,418 |
| Eligible images / captions | **122,204 / 611,349** |
| Eligible train2017 captions / val2017 captions | 586,360 / 24,989 |

The 83 additional candidates have minimum Hamming distances 2 (one image),
6 (12 images) or 8 (70 images). They were not adjudicated as 83 true duplicates.
The other two threshold-matching images are evaluation targets, COCO IDs 8471
and 254130. They form one conservative similarity group and should remain
together in any later pilot/confirmatory split. No study split was created here.

The screen cannot certify absence of every arbitrary crop, rotation, edit or
same-scene photograph. It also does not measure foundation-model pretraining
contamination. Semantically similar scenes are not excluded merely because
they resemble the target's meaning. All exclusion reasons, matching target IDs,
views and distances are retained for review.

**Frozen inputs and reproducibility deliverables**

| Source | Frozen revision or byte-level identity |
|---|---|
| BrainHub caption/reference files | `4838666f1a04d0521c2184fa50b5b77e7e7ac5ee` |
| UMBRAE exporter and download script | `8c1795c434a41cdd38ce6628b7e1a774f31d9483` |
| Subject-1 NSD test shards | HF `pscotti/naturalscenesdataset@421fb80ea4ca5600c7364ed400f9a5941380c387` |
| Image tensor | HF `weihaox/umbrae@77d4f8e1c1d6d417a363ac32c380f12924bd92c8` |
| Official NSD CSV/MAT and COCO ZIPs | Source URLs, actual sizes, SHA-256, HTTP ETags and Last-Modified values in `provenance.json` |

The source name `weihaox/brainx` resolves to the UMBRAE distribution and is not
an independent image source. The audited UMBRAE caption file is the original
variant, not `brainx-v-1-4`; see the [maintainer's version distinction](https://github.com/weihaox/BrainHub/issues/5#issuecomment-2497882317).
The COCO-reference route follows the [maintainer's metadata guidance](https://github.com/weihaox/BrainHub/issues/1#issuecomment-2186271204).

The actual SHA-256 values of all three HF files equal the pre-existing LFS
identifiers. Official S3 objects have locally computed SHA-256 values frozen
for reproduction, rather than independently published SHA-256 values. The
COCO annotation ZIP additionally matches its non-multipart MD5 ETag,
`f4bbac642086de4f52a3fdda2de5fa2c`. Multipart image-ZIP ETags were not treated
as MD5 hashes. Each annotation member has its own SHA-256 in the evidence.

The package includes:

- `alignment_manifest.jsonl`: all 2,946 caption rows, variants, source revisions,
  raw IDs, mapped IDs, caption/file hashes, crop provenance and per-row status.
- `sample_manifest.jsonl`: all 982 archive samples, member metadata/hashes,
  trial checks, padding checks, references and crop-check scope.
- All structural, negative-control, crop and corpus-screen results, plus the
  123,287-image fingerprint index and exact eligible/excluded identity lists.
- Runnable audit scripts, pinned input manifest, environment versions and a
  reproduction README. Package files are covered by `CHECKSUMS.sha256`.

The manifest SHA-256 is
`7cc41361c032146d42a65e12ed8623edf8e0ce282af18bb7fb060daf491f93c5`.
The sample-manifest SHA-256 is
`915020aaa374bf526c672982daf25d6a64a79f2249d411a9863c871e77ce4677`.
No voxel arrays, stimulus photographs, model weights or rewritten captions are
included in the deliverable package.

**Remaining limits and review decision**

No required asset for this cached-output alignment route remains missing.
Original decoder checkpoint hashes and complete original inference logs remain
unverified. The audit establishes the released benchmark's caption association,
not independent proof of how every caption was generated. UMBRAE has the most
direct inspected producer chain; the other two are named BrainHub comparison
exports. Their checkpoint fields remain explicitly unknown.

The original Brain-Imager's traceable pre/post-rewrite outputs and checkpoint
provenance have not been recovered by this work. Claims specifically about
that project's historical outputs would still require those assets, their IDs
and generation records. This does not block studying the verified public caches,
provided the paper names them accurately.

Only subject 1 was validated. COCO captions describe original images and are
not exhaustive factual ground truth for the displayed NSD crop. Later factuality
assessment must use the actual displayed crop, and later statistical analysis
must respect stimulus/repetition dependence and conservative similarity groups.
These are Phase 3 design constraints, not results of a RAG experiment.

**Recommendation: close the data-validation gate for the frozen cached-benchmark
route, subject to your review of this evidence. Do not make claims about an
unverified Brain-Imager checkpoint. No Phase 3 pilot, model call or writing of
experimental conclusions has begun.**
