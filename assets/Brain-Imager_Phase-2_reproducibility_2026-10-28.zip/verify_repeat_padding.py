"""Check actual archived repeat vectors; this does not run the decoder."""
from pathlib import Path
import io,json,tarfile,collections
import numpy as np
ROOT=Path(__file__).resolve().parent
records=json.loads((ROOT/'results/sample_records.json').read_text())
bykey={r['sample_key']:r for r in records}
checks=[]
for shard in ['test_subj01_0.tar','test_subj01_1.tar']:
    with tarfile.open(ROOT/'data'/shard) as z:
        for m in z:
            if not m.name.endswith('.nsdgeneral.npy'):continue
            key=m.name.rsplit('/',1)[-1].split('.')[0]
            r=bykey[key];a=np.load(io.BytesIO(z.extractfile(m).read()),allow_pickle=False)
            n=r['stored_num_uniques']
            if n==1:
                ok=bool(np.array_equal(a[0],a[1]) and np.array_equal(a[0],a[2]))
                rule='one observed response copied into all three rows'
            elif n==2:
                expected=a[:2].astype(np.float32).mean(axis=0).astype(a.dtype)
                ok=bool(np.array_equal(a[2],expected))
                rule='third row is float32 mean of first two, cast to stored float16'
            else:
                ok=np.unique(a,axis=0).shape[0]==3
                rule='three distinct rows; no padding detected'
            checks.append(dict(row_index=r['row_index'],observed_repetitions=n,
                stored_shape=list(a.shape),stored_dtype=str(a.dtype),rule=rule,pass_check=ok))
assert len(checks)==982 and all(c['pass_check'] for c in checks)
out=dict(records=len(checks),counts=dict(collections.Counter(c['observed_repetitions'] for c in checks)),
         all_pass=True,observed_trials=sum(c['observed_repetitions'] for c in checks),checks=checks)
(ROOT/'results/repeat_padding_check.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k!='checks'}))
