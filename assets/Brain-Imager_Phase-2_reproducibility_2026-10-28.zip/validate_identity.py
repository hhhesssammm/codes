"""Phase 2: exhaustive identity checks; no decoder or language-model inference."""
from pathlib import Path
import ast, collections, hashlib, io, json, platform, tarfile, zipfile
import numpy as np
import pandas as pd
from PIL import Image
from scipy.io import loadmat
import torch

ROOT=Path(__file__).resolve().parent
DATA=ROOT/"data"; OUT=ROOT/"results"; OUT.mkdir(exist_ok=True)
IMAGES=ROOT/"shard_images"; IMAGES.mkdir(exist_ok=True)
EXPECTED=982
def sha(b):return hashlib.sha256(b).hexdigest()
def plain(x):
    if isinstance(x,np.generic):return x.item()
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,Path):return str(x)
    raise TypeError(type(x).__name__)
def save(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2,default=plain)+"\n")
def strict_json(data):
    duplicates=[]
    def hook(pairs):
        d={}
        for k,v in pairs:
            if k in d:duplicates.append(k)
            d[k]=v
        return d
    value=json.loads(data,object_pairs_hook=hook)
    return value,duplicates

sources=json.loads((ROOT/"caption_verified_sources.json").read_text())
caption_sets={}; captions_info={}
for src in sources:
    raw=(ROOT/"captions"/Path(src["local_path"]).name).read_bytes()
    d,dups=strict_json(raw)
    if not isinstance(d,dict):raise ValueError("caption root not a mapping")
    keys=list(d);expected_keys={str(i) for i in range(EXPECTED)}
    inf=dict(source=src,rows=len(d),duplicate_json_keys=dups,
             missing_keys=sorted(expected_keys-set(keys)),extra_keys=sorted(set(keys)-expected_keys),
             insertion_order_numeric=keys==[str(i) for i in range(EXPECTED)],
             file_sha256=sha(raw))
    if src["label"]!="references":
        inf["invalid_or_empty_caption_keys"]=[k for k,v in d.items() if not isinstance(v,str) or not v.strip()]
        counts=collections.Counter(v for v in d.values() if isinstance(v,str))
        inf["distinct_caption_texts"]=len(counts)
        inf["repeated_caption_text_groups"]=sum(n>1 for n in counts.values())
    else:
        inf["reference_caption_count"]=sum(len(v) for v in d.values())
        inf["invalid_reference_keys"]=[k for k,v in d.items() if not isinstance(v,list) or not v or not all(isinstance(s,str) and s.strip() for s in v)]
    caption_sets[src["label"]]=d;captions_info[src["label"]]=inf

meta=pd.read_csv(DATA/"nsd_stim_info_merged.csv")
assert len(meta)==73000 and meta.nsdId.is_unique
assert np.array_equal(meta.nsdId.to_numpy(),np.arange(73000))
assert np.array_equal(meta["Unnamed: 0"].to_numpy(),meta.nsdId.to_numpy())
meta=meta.set_index("nsdId",drop=False)
design=loadmat(DATA/"nsd_expdesign.mat")
subject_sequence=design["subjectim"][0,design["masterordering"].ravel().astype(int)-1].astype(int)-1
shared0=design["sharedix"].ravel().astype(int)-1
assert set(shared0)==set(meta.index[meta.shared1000])
cached=torch.load(DATA/"all_images.pt",map_location="cpu",weights_only=True,mmap=True)
assert tuple(cached.shape)==(982,3,256,256)
torch.set_num_threads(1)
records=[];archive_counts={};reappeared=[];duplicate_members=[];global_keys=set()
for shard in ["test_subj01_0.tar","test_subj01_1.tar"]:
    samples=[];current_key=None;current=None
    with tarfile.open(DATA/shard,"r") as tf:
        for member in tf:
            if not member.isfile():continue
            name=member.name.rsplit("/",1)[-1]
            if "." not in name:raise ValueError("unrecognized member "+member.name)
            key,field=name.split(".",1)
            if key!=current_key:
                if key in global_keys:reappeared.append(key)
                global_keys.add(key)
                current=dict(sample_key=key,shard=shard,shard_record_index=len(samples),members={})
                samples.append(current);current_key=key
            if field in current["members"]:duplicate_members.append([key,field])
            current["members"][field]={"tar_name":member.name,"bytes":member.size}
            if field in {"coco73k.npy","trial.npy","num_uniques.npy","nsdgeneral.npy"}:
                b=tf.extractfile(member).read()
                a=np.load(io.BytesIO(b),allow_pickle=False)
                current["members"][field].update(sha256=sha(b),shape=list(a.shape),dtype=str(a.dtype))
                if field=="nsdgeneral.npy":
                    current["voxel_unique_rows"]=int(np.unique(a,axis=0).shape[0])
                else:
                    if a.shape!=(1,) or not np.issubdtype(a.dtype,np.integer):raise ValueError("unexpected ID representation")
                    current[field]=int(a[0])
            elif field in {"jpg","png"}:
                b=tf.extractfile(member).read()
                im=np.array(Image.open(io.BytesIO(b)).convert("RGB"))
                current["members"][field].update(sha256=sha(b),rgb_sha256=sha(im.tobytes()),image_shape=list(im.shape))
                j=len(records)+len(samples)-1
                t=cached[j].numpy().transpose(1,2,0)
                arr=np.rint(t*255).astype(np.uint8)
                current["cache_pixels_equal_shard"]=bool(np.array_equal(im,arr))
                current["cache_max_abs_float_difference"]=float(np.max(np.abs(t-im.astype(np.float32)/np.float32(255)))) if im.shape==t.shape else None
                current["cache_uint8_rgb_sha256"]=sha(arr.tobytes())
                (IMAGES/f"{j:04d}.{field}").write_bytes(b)
    archive_counts[shard]=len(samples);records.extend(samples)

required={"coco73k.npy","jpg","nsdgeneral.npy","num_uniques.npy","trial.npy","wholebrain_3d.npy"}
missing_fields=[]
for j,r in enumerate(records):
    if not required.issubset(r["members"]):missing_fields.append([j,sorted(required-set(r["members"]))])
    r.update(caption_key=str(j),row_index=j)
    raw=r["coco73k.npy"];trial=r["trial.npy"];m=meta.loc[raw]
    reps=[int(m[f"subject1_rep{i}"]) for i in range(3) if int(m[f"subject1_rep{i}"])>0]
    r["nsd_id_zero_based"]=raw
    r["nsd_id_one_based"]=raw+1
    r["coco_image_id"]=int(m.cocoId)
    r["coco_split"]=str(m.cocoSplit)
    r["crop_box"]=list(ast.literal_eval(m.cropBox))
    r["shared1000"]=bool(m.shared1000)
    r["subject1_membership"]=bool(m.subject1)
    r["official_subject1_trials_one_based"]=reps
    r["trial_matches_zero_based_design"]=bool(0<=trial<len(subject_sequence) and subject_sequence[trial]==raw)
    r["trial_matches_one_based_design"]=bool(1<=trial<=len(subject_sequence) and subject_sequence[trial-1]==raw)
    r["trial_plus_one_in_official_repetitions"]=trial+1 in reps
    r["available_repetitions_first37"]=sum(t<=27750 for t in reps)
    r["stored_num_uniques"]=r["num_uniques.npy"]
    shared_pos=np.where(shared0==raw)[0]
    r["shared_position_one_based"]=int(shared_pos[0])+1 if len(shared_pos)==1 else None
    r["official_png_name"]=f"shared{r['shared_position_one_based']:04d}_nsd{raw+1:05d}.png" if len(shared_pos)==1 else None
    r["official_png_url"]="https://natural-scenes-dataset.s3.amazonaws.com/nsddata/stimuli/nsd/shared1000/"+r["official_png_name"] if r["official_png_name"] else None

target_ids={r["coco_image_id"] for r in records};coco_refs=collections.defaultdict(list);coco_images={};coco_stats={}
zpath=DATA/"annotations_trainval2017.zip"
with zipfile.ZipFile(zpath) as z:
    for split in ["train2017","val2017"]:
        member=f"annotations/captions_{split}.json"
        b=z.read(member);doc,dups=strict_json(b)
        if dups:raise ValueError("duplicate JSON keys in COCO")
        coco_stats[split]=dict(images=len(doc["images"]),annotations=len(doc["annotations"]),member=member,member_sha256=sha(b))
        for im in doc["images"]:
            if im["id"] in coco_images:raise ValueError("duplicate COCO image ID across splits")
            coco_images[im["id"]]=dict(im,split=split)
        for a in doc["annotations"]:
            if a["image_id"] in target_ids:coco_refs[a["image_id"]].append(a)
save("coco_images_metadata.json",coco_images)
for r in records:
    refs=coco_refs[r["coco_image_id"]];bench=caption_sets["references"].get(r["caption_key"],[])
    expected=collections.Counter(a["caption"] for a in refs)
    r["coco_annotation_ids"]=[a["id"] for a in refs]
    r["coco_references_exact_match"]=expected==collections.Counter(bench)
    r["coco_references_whitespace_match"]=collections.Counter(" ".join(s.split()) for s in expected.elements())==collections.Counter(" ".join(s.split()) for s in bench)
    r["reference_caption_count"]=len(refs)
    r["coco_image_metadata_split_matches"]=coco_images[r["coco_image_id"]]["split"]==r["coco_split"]
    r["coco_original_width"]=coco_images[r["coco_image_id"]]["width"]
    r["coco_original_height"]=coco_images[r["coco_image_id"]]["height"]
    r["coco_license_id"]=coco_images[r["coco_image_id"]]["license"]
    r["coco_source_url"]=coco_images[r["coco_image_id"]].get("coco_url")
    r["flickr_url"]=coco_images[r["coco_image_id"]].get("flickr_url")

bool_checks=["cache_pixels_equal_shard","trial_matches_zero_based_design","trial_plus_one_in_official_repetitions",
"shared1000","subject1_membership","coco_references_exact_match","coco_references_whitespace_match","coco_image_metadata_split_matches"]
rawids=[r["coco73k.npy"] for r in records]
summary=dict(records=len(records),archive_counts=archive_counts,unique_sample_keys=len(global_keys),
    reappeared_sample_keys=reappeared,duplicate_members=duplicate_members,missing_fields=missing_fields,
    unique_nsd_ids=len(set(rawids)),unique_coco_ids=len(target_ids),nsd_ids_strictly_increasing=bool(np.all(np.diff(rawids)>0)),
    shared1000_missing_from_candidates=sorted(set(shared0)-set(rawids)),
    first37_shared_set_equals_candidates=set(subject_sequence[:27750])&set(shared0)==set(rawids),
    checks={k:{"pass":sum(bool(r[k]) for r in records),"fail_rows":[r["row_index"] for r in records if not r[k]]} for k in bool_checks},
    trial_one_based_alternative_matches=sum(r["trial_matches_one_based_design"] for r in records),
    actual_repeat_counts=dict(collections.Counter(r["stored_num_uniques"] for r in records)),
    repetitions_consistent_with_first37=sum(r["available_repetitions_first37"]==r["stored_num_uniques"] for r in records),
    voxel_unique_rows_consistent_with_metadata=sum(r["voxel_unique_rows"]==r["stored_num_uniques"] for r in records),
    image_shapes=dict(collections.Counter(str(r["members"]["jpg"]["image_shape"]) for r in records)),
    max_cache_float_difference=max(r["cache_max_abs_float_difference"] or 0 for r in records),
    exact_rgb_duplicate_groups=[],
    coco=coco_stats,caption_files=captions_info,
    environment=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,torch=torch.__version__))
groups=collections.defaultdict(list)
for r in records:groups[r["members"]["jpg"]["rgb_sha256"]].append(r["row_index"])
summary["exact_rgb_duplicate_groups"]=[v for v in groups.values() if len(v)>1]
save("identity_summary.json",summary)
save("sample_records.json",records)
# Deterministic sample independent of captions and outcomes, reproducible without RNG version assumptions.
chosen=sorted(records,key=lambda r:hashlib.sha256(("Brain-Imager|Phase2|2026-10-28|"+r["caption_key"]).encode()).hexdigest())[:20]
save("crop_check_selection.json",dict(method="20 lowest SHA-256 ranks of UTF-8 Brain-Imager|Phase2|2026-10-28|<caption_key>",rows=[r["row_index"] for r in chosen],samples=chosen))
print(json.dumps({k:v for k,v in summary.items() if k not in {"caption_files","environment","coco"}},default=plain,indent=2))
print("CAPTION_FILES",json.dumps({k:{a:b for a,b in v.items() if a!="source"} for k,v in captions_info.items()},default=plain))

