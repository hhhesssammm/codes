"""Fetch frozen caption bytes, or verify existing copies with --verify-only."""
from pathlib import Path
import hashlib,json,sys,urllib.request
ROOT=Path(__file__).resolve().parent;(ROOT/'captions').mkdir(exist_ok=True)
sources=json.loads((ROOT/'caption_verified_sources.json').read_text())
for s in sources:
    dest=ROOT/'captions'/Path(s['local_path']).name
    if '--verify-only' in sys.argv:b=dest.read_bytes()
    else:
        with urllib.request.urlopen(s['url'],timeout=60) as r:b=r.read()
    assert len(b)==s['size'],s['label']
    assert hashlib.sha256(b).hexdigest()==s['sha256'],s['label']
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==s['sha'],s['label']
    if '--verify-only' not in sys.argv:dest.write_bytes(b)
    print(s['label'],'byte size, SHA-256 and Git blob SHA-1 pass')
