# Brain-Imager Phase 2: cached benchmark identity validation

This package contains the completed data audit, per-row alignment manifests,
exclusion decisions, fingerprints, source hashes and executable audit scripts.
Pinned upstream code is linked and hashed in the inventory, rather than bundled.
It contains no NSD voxel arrays, stimulus photographs, decoder weights, caption
rewrites or RAG results. The user confirmed completion of the NSD data-access
agreement before the source files were downloaded or processed.

The audit label is 2026-10-28. Exact acquisition timestamps are recorded in UTC
in the provenance files; the downloads occurred on 2026-10-27 UTC. The fixed
sampling salt contains the audit label and must not be changed on reproduction.

**Read first:** the validation report, `results/manifest_integrity_check.json`,
`results/provenance.json`, and `results/retrieval_corpus_summary.json`.

**Manifest structure.** `results/alignment_manifest.jsonl` has 2,946 rows, one
per decoder and caption key. The primary key is `manifest_row_id`.
`results/sample_manifest.jsonl` has 982 rows and records the full sample-level
checks and raw archive-member metadata. `caption_row_index` joins to its
`row_index`; `sample_key`, NSD ID and COCO ID must also agree. No raw caption
text is republished: source URLs, file checksums and caption-text checksums
identify the exact input. Caption files can be downloaded and verified below.
Model checkpoint hashes are explicitly null because original inference traces
and weights were not independently audited.

**Data access and scope.** Reproduction requires authorized NSD access and
compliance with the original sources' terms. The agreement is not a blanket
license to redistribute NSD or COCO photographs. This package supplies derived
identity records and fingerprints. It validates published subject-1 benchmark
captions, not an unreleased Brain-Imager checkpoint. Sider Scholar was not used.

**Environment and resources.** Recorded Python 3.12.14; package versions appear
in `requirements-audit.txt` and `results/provenance.json`. Use a CPU environment
with several GB of RAM and at least 30 GB of free disk space for a full fresh
download. The image scan reads JPEGs inside the ZIP files; do not extract all
COCO images. The initial downloads total about 25.48 GB. No neural decoder,
captioner, LLM, embedding model or RAG pipeline is invoked by these scripts.

Run from the directory containing this README. Commands are sequential:

```bash
python -m pip install -r requirements-audit.txt
python -m pip install torch==2.14.1 --index-url https://download.pytorch.org/whl/cpu
python download_assets.py frozen_assets.json
python fetch_caption_sources.py
python validate_identity.py
python verify_repeat_padding.py
python verify_crops.py
python validate_alignment_controls.py
python screen_coco_images.py --force-image-scan
python build_manifests.py
```

The force flag is important for independent reproduction: it recomputes all
123,287 image fingerprints from the actual JPEGs and ZIP CRC checks. Without
the flag, the saved fingerprint index is reused to recompute exclusion decisions;
that faster route alone is not a fresh image-byte validation. The initial run
had no fingerprint cache. The downloader verifies the frozen SHA-256 values
even for existing files. It retries failed downloads from the beginning rather
than resuming partial transfers. On reproduction, the frozen hashes for official
S3 assets are checks against this audit's downloaded bytes; only the three HF
assets also had publisher-provided LFS SHA-256 values available beforehand.

`verify_crops.py` downloads the same 20 official PNGs selected by the lowest
SHA-256 ranks of `Brain-Imager|Phase2|2026-10-28|<caption_key>`. It creates local
contact sheets for authorized visual review. The original contact sheets and
stimulus images are deliberately absent from this package. Automated crop
metrics are recorded separately from the assistant's visual identity check.

**Exclusions.** All captions belonging to the 1,000 shared NSD image IDs are
excluded. Additional images are screened against the 982 evaluation targets
using source-photo aliases, JPEG and RGB hashes, and the prespecified pHash
rule in `exclusion_screen_plan.json`. Every threshold candidate is conservatively
excluded. This rule does not certify that all possible edited duplicates or
same-scene photographs have been detected. `eligible_coco_image_ids.txt` and
`eligible_coco_caption_ids.txt` are identity lists only; no retrieval index or
experimental output has been built. The two-target similarity group in
`target_similarity_groups.json` should remain together in any later pilot/
confirmatory allocation. No such allocation has been made in Phase 2.

**Hash interpretation.** `CHECKSUMS.sha256` covers the packaged files before
ZIP creation. `results/provenance.json` records input hashes and acquisition
metadata; individual source files and official crop PNGs have their own hashes.
The numeric contents of fingerprint arrays and mapping results are reproducible.
Fresh output timestamps and NPZ ZIP metadata can change container-file hashes
between equivalent reruns. Compare the underlying arrays, IDs and outcomes,
not a regenerated archive's timestamp-dependent hash alone.

**Review gate.** Required cached-route data checks passed. Phase 3 remains
unstarted and requires the user's review of this evidence. These results say
nothing about whether RAG increases or corrects factual errors.
